import { Injectable } from '@angular/core';
import { Aquarium } from '../aquarium/aquarium';
import { IAquarium } from '../aquarium/aquariumInterface';
import { Storage } from '@ionic/storage';
import { NgZone } from '@angular/core';

const AQUARIUMS_KEY = 'aquariums';

@Injectable({
    providedIn: 'root'
})
export class AquariumsService {
    //aquariums: Aquarium[] = [];

    constructor(private storage: Storage) {
        this.init();
    }

    public async addAquariumToStorage(data: IAquarium): Promise<void> {
        const newAquarium = new Aquarium(data);
        try {
            await this.storage.get(AQUARIUMS_KEY)
                .then((aquariums: Aquarium[]) => {
                    if (aquariums) {
                        aquariums.push(newAquarium);
                        this.storage.set(AQUARIUMS_KEY, aquariums);
                    } else {
                        this.storage.set(AQUARIUMS_KEY, [newAquarium]);
                    }
                });
        } catch (error) {
            console.log('Storage-Set-Error: ', error);
        }
    }

    public async getAquariumsFromStorage(): Promise<Aquarium[]> {
        try {
            return await this.storage.get(AQUARIUMS_KEY);
        } catch (error) {
            console.log('Storage-Get-Error: ', error);
        }
    }

    public async clearStorage(): Promise<void> {
        try {
            await this.storage.clear();
        } catch (error) {
            console.log('Storage-Clear-Error: ', error);
        }
    }

    private async init(): Promise<void> {
        try {
            await this.storage.create();
        } catch (error) {
            console.log('Storage-Init-Error: ', error);
        }
    }

    /*
    addAquariumToStorage(data: IAquarium) {
        const newAquarium = new Aquarium(data);
        this.storage.set(AQUARIUMS_KEY, newAquarium);
    }

    async getAquariumsFromStorage() {
        return await this.storage.get(AQUARIUMS_KEY);
    }

    clearStorage() {
        this.storage.clear();
    }

    init() {
        this.storage.create();
        this.storage.set(AQUARIUMS_KEY, []);
    }
    */

}
